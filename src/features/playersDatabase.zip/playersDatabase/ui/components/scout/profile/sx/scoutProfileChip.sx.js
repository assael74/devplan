import { devPlanColors } from '../../../../../../../ui/core/theme/Colors.js'

export const scoutProfileChipSx = {
  root: ({ interactive, compact, width, isFilter = false, selected = false }) => ({
    position: 'relative',
    width: width || (compact ? 146 : 176),
    maxWidth: '100%',
    minHeight: compact ? 22 : 30,
    overflow: 'hidden',
    display: 'grid',
    border: isFilter
      ? `1px solid ${selected ? 'rgba(255, 255, 255, 0.96)' : devPlanColors.tertiary}`
      : `1px solid ${devPlanColors.border}`,
    borderRadius: 999,
    bgcolor: isFilter ? devPlanColors.tertiary : devPlanColors.tertiaryLight,
    color: isFilter ? '#fff' : devPlanColors.primaryDark,
    outline: isFilter && selected ? '1px solid rgba(255, 255, 255, 0.72)' : 'none',
    outlineOffset: 2,
    cursor: interactive ? 'pointer' : 'default',
    font: 'inherit',
    textAlign: 'inherit',
    appearance: 'none',
    '&:hover': interactive
      ? {
          borderColor: devPlanColors.tertiaryDark,
        }
      : {},
    '&:focus-visible': interactive ? {
      outline: `2px solid ${devPlanColors.primary}`,
      outlineOffset: 2,
    } : {},
  }),

  fill: ({ depthPct }) => ({
    position: 'absolute',
    zIndex: 0,
    inset: '0 auto 0 0',
    width: `${depthPct}%`,
    bgcolor: devPlanColors.tertiary,
    transition: 'width 220ms ease',
  }),

  content: ({ compact }) => ({
    position: 'relative',
    zIndex: 1,
    minWidth: 0,
    minHeight: compact ? 22 : 30,
    py: compact ? 0 : 0.15,
    px: compact ? 0.5 : 0.7,
    display: 'grid',
    gridTemplateColumns: compact ? '20px minmax(0, 1fr) auto' : '26px minmax(0, 1fr) auto',
    alignItems: 'center',
    gap: compact ? 0.4 : 0.55,
  }),

  icon: ({ compact, isFilter = false, isCombination = false }) => ({
    width: compact ? 18 : 24,
    height: compact ? 18 : 24,
    display: 'grid',
    placeItems: 'center',
    borderRadius: '50%',
    border: isFilter ? 'none' : '1px solid rgba(23, 59, 87, 0.28)',
    bgcolor: isFilter ? 'transparent' : 'rgba(255, 255, 255, 0.9)',
    color: isCombination ? '#F2B84B' : isFilter ? '#fff' : devPlanColors.primary,
    '& svg': {
      color: isCombination ? '#F2B84B' : isFilter ? '#fff' : 'inherit',
      fontSize: compact ? 11 : 14,
    },
  }),

  label: ({ compact, isFilter = false }) => ({
    minWidth: 0,
    overflow: 'hidden',
    color: isFilter ? '#fff' : devPlanColors.primaryDark,
    fontSize: compact ? 11 : 12,
    fontWeight: 700,
    lineHeight: 1,
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
  }),

  endLabel: ({ compact }) => ({
    minWidth: compact ? 24 : 28,
    height: compact ? 17 : 22,
    px: compact ? 0.45 : 0.6,
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 999,
    border: '1px solid rgba(23, 59, 87, 0.1)',
    bgcolor: 'rgba(255, 255, 255, 0.84)',
    color: devPlanColors.primaryDark,
    fontSize: compact ? 10 : 11,
    fontWeight: 800,
    fontVariantNumeric: 'tabular-nums',
  }),

  tooltip: {
    color: `${devPlanColors.primaryDark} !important`,
    bgcolor: `${devPlanColors.tertiaryLight} !important`,
    border: `1px solid ${devPlanColors.tertiary} !important`,
    borderRadius: '9px !important',
    p: '0 !important',
    boxShadow: '0 8px 22px rgba(22, 42, 59, 0.14)',
  },
}
