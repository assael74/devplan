import { devPlanColors } from '../../../../../../../ui/core/theme/Colors.js'

export const scoutProfileTooltipSx = {
  root: ({ compact = false } = {}) => ({
    width: compact ? 300 : 340,
    minHeight: 0,
    maxHeight: compact ? 250 : 300,
    maxWidth: compact ? 'min(300px, calc(100vw - 32px))' : 'min(340px, calc(100vw - 32px))',
    display: 'grid',
    gap: compact ? 0.55 : 0.85,
    p: compact ? 0.75 : 1,
    overflowY: 'auto',
    scrollbarWidth: 'thin',
    scrollbarColor: `${devPlanColors.tertiary} transparent`,
    '&::-webkit-scrollbar': {
      width: 5,
    },
    '&::-webkit-scrollbar-thumb': {
      backgroundColor: devPlanColors.tertiary,
      borderRadius: 99,
    },
    color: devPlanColors.primaryDark,
    bgcolor: devPlanColors.tertiaryLight,
    border: `1px solid ${devPlanColors.tertiary}`,
    borderRadius: 9,
  }),

  profileSection: ({ divided = false, compact = false } = {}) => ({
    display: 'grid',
    gap: compact ? 0.55 : 0.85,
    ...(divided
      ? {
        borderTop: `1px solid rgba(23, 59, 87, 0.18)`,
        paddingTop: compact ? 0.55 : 0.85,
      }
      : {}),
  }),

  header: () => ({
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 0.75,
  }),

  profileTitle: () => ({
    minWidth: 0,
    display: 'flex',
    alignItems: 'center',
    gap: 0.55,
  }),

  profileIcon: ({ compact = false } = {}) => ({
    width: compact ? 19 : 23,
    height: compact ? 19 : 23,
    flex: '0 0 auto',
    display: 'grid',
    placeItems: 'center',
    color: devPlanColors.primary,
    bgcolor: 'rgba(255, 255, 255, 0.78)',
    border: '1px solid rgba(23, 59, 87, 0.18)',
    borderRadius: '50%',
    '& svg': {
      fontSize: compact ? 11 : 13,
    },
  }),

  title: ({ compact = false } = {}) => ({
    minWidth: 0,
    color: devPlanColors.primaryDark,
    fontSize: compact ? 11.5 : 13,
    fontWeight: 800,
    lineHeight: 1.2,
  }),

  createdAt: ({ compact = false } = {}) => ({
    flex: '0 0 auto',
    color: devPlanColors.secondary,
    fontSize: compact ? 9.5 : 10.5,
    fontWeight: 700,
    whiteSpace: 'nowrap',
  }),

  conditionsLabel: ({ compact = false } = {}) => ({
    display: 'inline-flex',
    alignSelf: 'start',
    justifySelf: 'start',
    width: 'auto',
    color: devPlanColors.primaryDark,
    fontSize: compact ? 10 : 11,
    fontWeight: 800,
    lineHeight: 1,
    borderBottom: `1px solid ${devPlanColors.primaryDark}`,
    paddingBottom: 0,
  }),

  conditions: {
    display: 'grid',
    gap: 0.15,
  },

  condition: () => ({
    display: 'grid',
    gap: 0.05,
  }),

  conditionMeta: () => ({
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 0.75,
  }),

  conditionTitle: () => ({
    minWidth: 0,
    display: 'flex',
    alignItems: 'center',
    gap: 0.45,
  }),

  conditionIcon: ({ compact = false } = {}) => ({
    width: compact ? 15 : 17,
    height: compact ? 15 : 17,
    flex: '0 0 auto',
    display: 'grid',
    placeItems: 'center',
    color: devPlanColors.tertiaryDark,
    '& svg': {
      fontSize: compact ? 10 : 12,
    },
  }),

  conditionLabel: ({ compact = false } = {}) => ({
    minWidth: 0,
    color: devPlanColors.primaryDark,
    fontSize: compact ? 9.5 : 10.5,
    fontWeight: 600,
    lineHeight: 1.1,
  }),

  conditionProgress: ({ compact = false } = {}) => ({
    flex: '0 0 auto',
    color: devPlanColors.primary,
    fontSize: compact ? 9.5 : 10.5,
    fontWeight: 800,
    lineHeight: 1,
  }),

  conditionStatus: ({ compact = false } = {}) => ({
    flex: '0 0 auto',
    color: devPlanColors.successDark,
    fontSize: compact ? 9 : 10,
    fontWeight: 800,
    lineHeight: 1,
    whiteSpace: 'nowrap',
  }),

  progressTrack: ({ compact = false } = {}) => ({
    '--LinearProgress-trackColor': 'rgba(23, 59, 87, 0.12)',
    '--LinearProgress-progressColor': devPlanColors.tertiary,
    '--LinearProgress-thickness': compact ? '2px' : '3px',
    minHeight: compact ? 2 : 3,
    height: compact ? 2 : 3,
  }),

  emptyState: ({ compact = false } = {}) => ({
    color: devPlanColors.secondary,
    fontSize: compact ? 9.5 : 10.5,
  }),
}
