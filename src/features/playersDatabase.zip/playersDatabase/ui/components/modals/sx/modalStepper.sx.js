import { devPlanColors } from '../../../../../../ui/core/theme/Colors.js'

const stepNumber = {
  width: 28,
  height: 28,
  display: 'grid',
  placeItems: 'center',
  borderRadius: '50%',
  bgcolor: devPlanColors.border,
  color: devPlanColors.secondary,
  fontSize: 12,
  fontWeight: 700,
}

const stepLabel = {
  maxWidth: '100%',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
  color: devPlanColors.secondary,
  textAlign: 'center',
}

export const modalStepperSx = {
  stepBar: {
    px: 2,
    py: 1.25,
    display: 'flex',
    gap: 0.75,
    border: `1px solid ${devPlanColors.border}`,
    borderRadius: 12,
    bgcolor: devPlanColors.secondaryLight,
    overflow: 'hidden',
  },

  stepBarCompact: {
    px: 2,
    py: 0.75,
  },

  stepItem: {
    minWidth: 0,
    flex: 1,
    display: 'grid',
    justifyItems: 'center',
    gap: 0.5,
  },

  stepItemCompact: {
    gap: 0.25,
  },

  resolveStepNumber: (active, complete, disabled, compact = false) => ({
    ...stepNumber,
    ...(compact ? {
      width: 24,
      height: 24,
      fontSize: 11,
    } : {}),
    ...(active ? {
      bgcolor: devPlanColors.primary,
      color: '#fff',
    } : {}),
    ...(complete ? {
      bgcolor: devPlanColors.tertiaryLight,
      color: devPlanColors.tertiaryDark,
    } : {}),
    ...(disabled ? {
      opacity: 0.55,
    } : {}),
  }),

  resolveStepLabel: (active, disabled) => ({
    ...stepLabel,
    ...(active ? {
      color: devPlanColors.primaryDark,
      fontWeight: 700,
    } : {}),
    ...(disabled ? {
      opacity: 0.55,
    } : {}),
  }),
}
