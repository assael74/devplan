// features/playersDatabase/services/write/searchIndex/delete/searchIndex.delete.js

import {
  collection,
  query,
  where,
} from 'firebase/firestore'
import {
  createTrackedWriteBatch,
  trackedGetDocs,
} from '../../../../../../services/firestore/usage/index.js'
import { db } from '../../../../../../services/firebase/firebase.js'
import { PLAYERS_DATABASE_COLLECTIONS } from '../../../../constants/pdb.constants.js'
import { normalizeSeasonIdentity } from '../../../../model/shared/season.model.js'
import { normalizeTeamIdentity } from '../../../../model/team/teamIdentity.model.js'
import {
  clean,
  toNumberOrZero,
} from '../../leagues/leagueDoc.js'
import { resetTeamSeasonSearchIndexToLeagueOnly } from '../team/index.js'
import {
  collectIndexMeta,
  dataMatchesPlayer,
} from '../read/searchIndexMeta.read.js'
import { buildSearchIndexWriteResult } from '../shared/searchIndexResult.model.js'
import { commitBatchWhenNeeded } from '../shared/searchIndexBatch.write.js'

const readSearchIndexes = queryRef => trackedGetDocs(queryRef, {
  feature: 'playersDatabase',
  collection: PLAYERS_DATABASE_COLLECTIONS.searchIndexes,
  action: 'searchIndex-delete',
  operationSubtype: 'maintenance-query',
})

const deleteSnapshotDocs = async snapshot => {
  const batch = createTrackedWriteBatch(db, {
    feature: 'playersDatabase',
    collection: PLAYERS_DATABASE_COLLECTIONS.searchIndexes,
    action: 'searchIndex-delete',
    operationSubtype: 'maintenance-batch',
  })

  snapshot.docs.forEach(indexDoc => {
    batch.delete(indexDoc.ref)
  })

  await commitBatchWhenNeeded({
    batch,
    operationsCount: snapshot.docs.length,
  })

  return snapshot.docs.length
}

export async function deleteSearchIndexesForLeagueSeason({
  league = {},
  season = {},
} = {}) {
  const leagueId = clean(league.id || season.leagueId)
  const seasonIdentity = normalizeSeasonIdentity({ season })
  const seasonKey = seasonIdentity.seasonKey
  if (!leagueId) throw new Error('Missing league id')
  if (!seasonKey) throw new Error('Missing season key')

  const rowsQuery = query(
    collection(db, PLAYERS_DATABASE_COLLECTIONS.searchIndexes),
    where('leagueId', '==', leagueId),
    where('seasonKey', '==', seasonKey)
  )
  const snapshot = await readSearchIndexes(rowsQuery)
  const meta = collectIndexMeta(snapshot)
  const rowsCount = await deleteSnapshotDocs(snapshot)

  return buildSearchIndexWriteResult({
    operation: 'deleteLeagueSeason',
    rowsCount,
    ...meta,
  })
}


export async function deleteSearchIndexesForTeamSeason({
  league = {},
  season = {},
  team = {},
} = {}) {
  const leagueId = clean(league.id || season.leagueId || team.leagueId)
  const seasonIdentity = normalizeSeasonIdentity({ season })
  const seasonKey = seasonIdentity.seasonKey
  const teamIdentity = normalizeTeamIdentity({ team })
  const teamId = clean(teamIdentity.birthTeamId || teamIdentity.teamId)
  const birthTeamSlot = teamIdentity.birthTeamSlot || 1
  if (!seasonKey) throw new Error('Missing season key')
  if (!teamId) throw new Error('Missing birth team id')

  const playerRowsQuery = query(
    collection(db, PLAYERS_DATABASE_COLLECTIONS.searchIndexes),
    where('entityType', '==', 'playerSeason'),
    where('seasonKey', '==', seasonKey),
    where('birthTeamId', '==', teamId)
  )
  const playerSnapshot = await readSearchIndexes(playerRowsQuery)
  const matchingPlayerDocs = {
    docs: playerSnapshot.docs.filter(indexDoc => {
      const data = indexDoc.data() || {}
      if (birthTeamSlot && toNumberOrZero(data.birthTeamSlot) !== birthTeamSlot) return false
      if (leagueId && clean(data.leagueId) && clean(data.leagueId) !== leagueId) return false

      return true
    }),
  }
  const meta = collectIndexMeta(matchingPlayerDocs)
  const playerRowsCount = await deleteSnapshotDocs(matchingPlayerDocs)
  const teamIndexResult = await resetTeamSeasonSearchIndexToLeagueOnly({
    league,
    season,
    team,
    target: clean(season.seasonStatus) === 'completed' ? 'history' : 'current',
  })
  const teamRowsCount = teamIndexResult.rowsCount

  return buildSearchIndexWriteResult({
    operation: 'deleteTeamSeason',
    rowsCount: playerRowsCount + teamRowsCount,
    playerRowsCount,
    teamRowsCount,
    teamIndexResult,
    ...meta,
  })
}

export async function deleteSearchIndexForTeamPlayerSeason({
  season = {},
  team = {},
  player = {},
} = {}) {
  const seasonIdentity = normalizeSeasonIdentity({ season })
  const seasonKey = seasonIdentity.seasonKey
  const teamIdentity = normalizeTeamIdentity({ team })
  const teamId = clean(teamIdentity.birthTeamId || teamIdentity.teamId)
  const leagueId = clean(season.leagueId || team.leagueId)
  const birthTeamSlot = teamIdentity.birthTeamSlot || 1
  if (!seasonKey) throw new Error('Missing season key')
  if (!teamId) throw new Error('Missing birth team id')

  const rowsQuery = query(
    collection(db, PLAYERS_DATABASE_COLLECTIONS.searchIndexes),
    where('entityType', '==', 'playerSeason'),
    where('seasonKey', '==', seasonKey),
    where('birthTeamId', '==', teamId)
  )
  const snapshot = await readSearchIndexes(rowsQuery)
  const matchingDocs = {
    docs: snapshot.docs.filter(indexDoc => {
      const data = indexDoc.data() || {}
      if (birthTeamSlot && toNumberOrZero(data.birthTeamSlot) !== birthTeamSlot) return false
      if (leagueId && clean(data.leagueId) && clean(data.leagueId) !== leagueId) return false

      return dataMatchesPlayer(data, player)
    }),
  }
  const scopedRowsCount = snapshot.docs.filter(indexDoc => {
    const data = indexDoc.data() || {}
    if (birthTeamSlot && toNumberOrZero(data.birthTeamSlot) !== birthTeamSlot) return false
    if (leagueId && clean(data.leagueId) && clean(data.leagueId) !== leagueId) return false

    return true
  }).length
  const meta = collectIndexMeta(matchingDocs)
  const rowsCount = await deleteSnapshotDocs(matchingDocs)
  const remainingRowsCount = Math.max(0, scopedRowsCount - rowsCount)

  return buildSearchIndexWriteResult({
    operation: 'deleteTeamPlayerSeason',
    rowsCount,
    remainingRowsCount,
    ...meta,
  })
}





export async function deletePlayerSearchIndexesForTeamSeason({
  league = {},
  season = {},
  team = {},
} = {}) {
  const leagueId = clean(league.id || season.leagueId || team.leagueId)
  const seasonIdentity = normalizeSeasonIdentity({ season })
  const seasonKey = seasonIdentity.seasonKey
  const teamIdentity = normalizeTeamIdentity({ team })
  const teamId = clean(teamIdentity.birthTeamId || teamIdentity.teamId)
  const birthTeamSlot = teamIdentity.birthTeamSlot || 1
  if (!seasonKey) throw new Error('Missing season key')
  if (!teamId) throw new Error('Missing birth team id')

  const rowsQuery = query(
    collection(db, PLAYERS_DATABASE_COLLECTIONS.searchIndexes),
    where('entityType', '==', 'playerSeason'),
    where('seasonKey', '==', seasonKey),
    where('birthTeamId', '==', teamId)
  )
  const snapshot = await readSearchIndexes(rowsQuery)
  const matchingDocs = {
    docs: snapshot.docs.filter(indexDoc => {
      const data = indexDoc.data() || {}
      if (toNumberOrZero(data.birthTeamSlot) !== birthTeamSlot) return false
      if (leagueId && clean(data.leagueId) && clean(data.leagueId) !== leagueId) return false
      return true
    }),
  }
  const meta = collectIndexMeta(matchingDocs)
  const rowsCount = await deleteSnapshotDocs(matchingDocs)

  return buildSearchIndexWriteResult({
    operation: 'deleteTeamSeasonPlayerIndexes',
    rowsCount,
    ...meta,
  })
}
