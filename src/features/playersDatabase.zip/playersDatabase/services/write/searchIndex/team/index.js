// src/features/playersDatabase/services/write/searchIndex/team/index.js

/**
 * Team-season search-index write services
 *
 * teamSeasonIndex.model.js
 * - Builds the team-season index identity and complete document shape.
 * - Normalizes league-table and team-scoring values used by the index.
 *
 * teamSeasonIndex.upsert.js
 * - Creates or refreshes team-season index documents from league-table rows.
 *
 * teamSeasonIndex.patch.js
 * - Applies focused updates to one team-season index document.
 * - Updates roster metadata, team URL and scout-profile summaries.
 *
 * teamSeasonIndex.bulk.js
 * - Applies season-level updates to multiple team-season index documents.
 *
 */

export {
  buildTeamSeasonIndexId,
} from './teamSeasonIndex.model.js'

export {
  buildTeamSeasonSearchIndexDocuments,
  upsertTeamSeasonSearchIndexMany,
} from './teamSeasonIndex.upsert.js'

export {
  resetTeamSeasonSearchIndexToLeagueOnly,
  updateTeamSeasonSearchIndexRosterMeta,
  updateTeamSeasonSearchIndexScoutProfilesSummary,
  updateTeamSeasonSearchIndexTeamUrl,
} from './teamSeasonIndex.patch.js'

export {
  updateSearchIndexesLeagueSeasonUrl,
  updateTeamSeasonSearchIndexesSeasonMeta,
} from './teamSeasonIndex.bulk.js'
