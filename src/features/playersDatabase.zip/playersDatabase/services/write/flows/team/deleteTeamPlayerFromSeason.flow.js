// features/playersDatabase/services/write/flows/team/deleteTeamPlayerFromSeason.flow.js

import {
  updateLeagueSeasonTableRankScoutProfilesSummary,
  updateLeagueSeasonTableRankTeamUrl,
} from '../../leagues/index.js'
import { removePlayerSeasonDocsMany } from '../../players/index.js'
import {
  deleteSearchIndexForTeamPlayerSeason,
  updateTeamSeasonSearchIndexRosterMeta,
  updateTeamSeasonSearchIndexScoutProfilesSummary,
} from '../../searchIndex/index.js'
import { removeTeamPlayerFromSeason } from '../../teams/index.js'
import {
  ensureRequiredClubProjectionCompleted,
  syncClubProjectionFromTeamSeason,
} from '../../clubs/index.js'
import { buildTeamLoadStatus } from '../../../../model/team/teamLoadStatus.model.js'

const runDeleteStage = async ({
  stage,
  results,
  action,
}) => {
  try {
    const result = await action()
    results[stage] = result

    if (stage === 'clubProjection' && result?.completed !== true) {
      throw new Error(result?.reason || 'Required Club projection did not complete')
    }

    return result
  } catch (error) {
    error.name = 'TeamPlayerSeasonDeleteError'
    error.stage = stage
    error.results = results
    throw error
  }
}

export async function deleteTeamPlayerFromSeasonFlow(payload = {}) {
  const player = payload.player || {}
  const results = {}

  const teamPlayerResult = await runDeleteStage({
    stage: 'removeTeamPlayerFromSeason',
    results,
    action: () => removeTeamPlayerFromSeason({
      ...payload,
      player,
    }),
  })

  if (!teamPlayerResult.removed) {
    const error = new Error('Team player was not removed from the team season')
    error.name = 'TeamPlayerSeasonDeleteError'
    error.stage = 'removeTeamPlayerFromSeason'
    error.results = results
    throw error
  }

  const playerDocumentIds = Array.isArray(teamPlayerResult.playerDocumentIds)
    ? teamPlayerResult.playerDocumentIds
    : []

  const playerSeasonDocsResult = await runDeleteStage({
    stage: 'removePlayerSeasonDocsMany',
    results,
    action: () => removePlayerSeasonDocsMany({
      ...payload,
      playerDocumentIds,
    }),
  })

  const searchIndexResult = await runDeleteStage({
    stage: 'deleteSearchIndexForTeamPlayerSeason',
    results,
    action: () => deleteSearchIndexForTeamPlayerSeason({
      ...payload,
      player,
    }),
  })

  const teamWithRosterMeta = {
    ...(payload.team || {}),
    ...buildTeamLoadStatus(teamPlayerResult.players),
  }

  const leagueTableRankResult = await runDeleteStage({
    stage: 'updateLeagueSeasonTableRankTeamUrl',
    results,
    action: () => updateLeagueSeasonTableRankTeamUrl({
      ...payload,
      team: teamWithRosterMeta,
    }),
  })

  const leagueTableRankScoutProfilesResult = await runDeleteStage({
    stage: 'updateLeagueSeasonTableRankScoutProfilesSummary',
    results,
    action: () => updateLeagueSeasonTableRankScoutProfilesSummary({
      ...payload,
      team: payload.team || {},
      scoutProfilesSummary: teamPlayerResult.scoutProfilesSummary,
      teamTaskSignals: teamPlayerResult.teamBalance?.teamTaskSignals,
    }),
  })

  const teamSeasonIndexResult = await runDeleteStage({
    stage: 'updateTeamSeasonSearchIndexRosterMeta',
    results,
    action: () => updateTeamSeasonSearchIndexRosterMeta({
      ...payload,
      team: teamWithRosterMeta,
      teamSeasonDocumentId: teamPlayerResult.teamSeasonDocumentId,
      playersCount: teamPlayerResult.playersCount,
      playerSeasonIndexCount: searchIndexResult.remainingRowsCount,
      teamBalance: teamPlayerResult.teamBalance,
    }),
  })

  const teamSeasonIndexScoutProfilesResult = await runDeleteStage({
    stage: 'updateTeamSeasonSearchIndexScoutProfilesSummary',
    results,
    action: () => updateTeamSeasonSearchIndexScoutProfilesSummary({
      ...payload,
      team: payload.team || {},
      teamSeasonDocumentId: teamPlayerResult.teamSeasonDocumentId,
      scoutProfilesSummary: teamPlayerResult.scoutProfilesSummary,
    }),
  })


  const clubProjectionResult = await runDeleteStage({
    stage: 'clubProjection',
    results,
    action: async () => ensureRequiredClubProjectionCompleted(await syncClubProjectionFromTeamSeason({
      league: payload.league || {},
      season: payload.season || {},
      team: teamWithRosterMeta,
      teamSeason: teamPlayerResult.seasonDocument || {},
      canonicalCommitted: true,
      lastWriteAction: 'DELETE_TEAM_PLAYER_FROM_SEASON',
    })),
  })

  return {
    teamPlayerResult,
    playerSeasonDocsResult,
    searchIndexResult,
    leagueTableRankResult,
    leagueTableRankScoutProfilesResult,
    teamSeasonIndexResult,
    teamSeasonIndexScoutProfilesResult,
    clubProjectionResult,
    rowsCount: searchIndexResult.rowsCount,
    teamCanonicalCommitted: true,
    projectionsCompleted: true,
    completed: true,
    syncStatus: 'complete',
  }
}
