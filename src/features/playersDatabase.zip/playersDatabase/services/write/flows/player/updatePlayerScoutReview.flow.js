// src/features/playersDatabase/services/write/flows/player/updatePlayerScoutReview.flow.js

import { getTeamSeason } from '../../../read/teamSeason.js'
import {
  ensureManualScoutingPlayerDoc,
  updateScoutingPlayerReview,
} from '../../players/index.js'
import { updatePlayerSeasonSearchIndexScoutProfiles } from '../../searchIndex/index.js'
import { clean } from '../../leagues/leagueDoc.js'

const resolveTeamDocumentId = team => clean(
  team?.birthTeamDocumentId ||
  team?.birthTeamId ||
  team?.teamDocumentId ||
  team?.teamId
)

const ensureReviewPlayerDocument = async payload => {
  const firstResult = await updateScoutingPlayerReview(payload)

  if (firstResult.reason !== 'playerDocMissing') return firstResult

  const teamDocumentId = resolveTeamDocumentId(payload.team || {})
  const teamSeasonDocument = teamDocumentId ? await getTeamSeason({
    birthTeamDocumentId: teamDocumentId,
    seasonKey: payload.season?.seasonKey || payload.season?.seasonId,
  }) : null
  const ensureResult = await ensureManualScoutingPlayerDoc({
    ...payload,
    teamSeasonDocument,
  })

  if (ensureResult.skipped) {
    return {
      ...ensureResult,
      updated: false,
    }
  }

  return updateScoutingPlayerReview({
    ...payload,
    player: {
      ...(payload.player || {}),
      playerDocumentId: ensureResult.playerDocumentId,
    },
  })
}

export async function updatePlayerScoutReviewFlow(payload = {}) {
  let reviewResult = null

  try {
    reviewResult = await ensureReviewPlayerDocument(payload)
  } catch (error) {
    return {
      reviewResult: null,
      playerSeasonIndexResult: null,
      humanStateCommitted: false,
      projectionsCompleted: false,
      completed: false,
      stoppedAt: 'humanReview',
      error: clean(error?.message) || 'Player review write failed',
    }
  }

  if (!reviewResult.updated) {
    return {
      reviewResult,
      playerSeasonIndexResult: null,
      humanStateCommitted: false,
      projectionsCompleted: false,
      completed: false,
    }
  }

  const seasonPlayer = reviewResult.seasonPlayer

  if (!seasonPlayer) {
    return {
      reviewResult,
      playerSeasonIndexResult: null,
      humanStateCommitted: true,
      projectionsCompleted: false,
      completed: true,
      stoppedAt: 'playerSeasonMissing',
    }
  }

  try {
    const playerSeasonIndexResult = await updatePlayerSeasonSearchIndexScoutProfiles({
      ...payload,
      player: seasonPlayer,
    })

    if (!playerSeasonIndexResult?.updated) {
      return {
        reviewResult,
        playerSeasonIndexResult,
        humanStateCommitted: true,
        projectionsCompleted: false,
        completed: true,
        stoppedAt: 'playerSearchIndex',
        projectionError: clean(
          playerSeasonIndexResult?.reason ||
          'Player season SearchIndex is missing'
        ),
      }
    }

    return {
      reviewResult,
      playerSeasonIndexResult,
      humanStateCommitted: true,
      projectionsCompleted: true,
      completed: true,
    }
  } catch (error) {
    return {
      reviewResult,
      playerSeasonIndexResult: null,
      humanStateCommitted: true,
      projectionsCompleted: false,
      completed: true,
      projectionError: clean(error?.message) || 'Player review projection sync failed',
    }
  }
}
