# TEAM_DATA_ARCHITECTURE.md

## Purpose

This document defines the canonical data architecture and source-of-truth rules for `src/features/playersDatabase`.

Any change affecting Team, Player, SearchIndex, Roster Load, Stats Load, Audit, Repair, Migration, or Firestore persistence must be checked against this document before implementation.

The goal is to prevent different writers or flows from independently deciding:
- where data comes from,
- which layer owns it,
- which layer may overwrite it,
- and which values are canonical versus derived projections.

---

# 1. Core architecture principles

## 1.1 Firestore persistence layers

The main persisted layers are:

1. **League Document**
   - Canonical source for official team competition performance.
   - Contains league table rows for teams and season context.

2. **Team Root Document** (`dbBirthTeams/{birthTeamDocumentId}`)
   - Stable identity for a birth-year team only.
   - Holds only root identity fields and `seasons[]`, a compact navigation index of
     `{ seasonKey, seasonDocumentId, seasonStatus }`.
   - It never owns roster, statistics, balance, performance, scouting, or a
     `current/history` season payload.

3. **Team Season Document** (`dbBirthTeamSeasons/{birthTeamSeasonDocumentId}`)
   - The single source of truth for one Team + Season.
   - Owns `teamPlayers`, stats, League-derived performance projection, Team
     Balance, scout summary and season metadata.
   - `birthTeamDocumentId` is the relation back to the Team Root; `seasons[]`
     on the Root is navigation only and is never a second seasonal source.

4. **Player Document**
   - Source of truth for tracked-player history and human scouting state.
   - Does not store the entire scouting engine output.

5. **SearchIndex Documents**
   - Projection layer only.
   - Never a source of truth.
   - Must be reproducible from canonical persisted data.

---


# 1A. Firestore document catalog — schema source of truth

The canonical source of truth for the **persisted Firestore document structure** is:

`src/features/playersDatabase/catalog/firestoreDocuments`

This catalog defines what the Firestore documents are expected to contain.

It is the schema/source-of-truth layer for:
- allowed persisted fields,
- document shapes,
- nested structures,
- defaults where explicitly defined,
- expected persisted contracts for Team, Player, and SearchIndex documents.

The catalog must be treated differently from this architecture document:

- `TEAM_DATA_ARCHITECTURE.md` defines **why data exists, who owns it, where it comes from, and which flow may write it**.
- `catalog/firestoreDocuments` defines **what the persisted Firestore document is structurally expected to look like**.

Neither replaces the other.

A valid persistence change must satisfy both:
1. the architecture/source-of-truth rules in this document;
2. the document schema contract in `catalog/firestoreDocuments`.

## Catalog precedence rules

When working on Firestore persistence:

- Do not add a persisted field only in a writer without updating the relevant catalog contract.
- Do not remove or rename a persisted field only in a writer while leaving the catalog stale.
- Do not treat writer output as the schema source of truth.
- Do not infer document structure from existing Firestore documents when the catalog defines the intended structure.
- Do not let Audit, Repair, Migration, or SearchIndex introduce fields that are outside the intended catalog contract.
- If the architecture says a field must not be persisted, the catalog must not continue to require it.
- If the catalog and writer disagree, treat the disagreement as a schema/implementation mismatch that must be resolved deliberately.

## Recommended validation order

For any Team / Player / SearchIndex persistence change:

```text
Architecture rule
    ↓
Firestore document catalog
    ↓
Domain / canonical builder
    ↓
Writer
    ↓
SearchIndex projection
    ↓
Audit / Repair / Migration validation
```

The intended contract is therefore:

```text
TEAM_DATA_ARCHITECTURE.md
    = source of truth for ownership, meaning and data flow

catalog/firestoreDocuments
    = source of truth for persisted Firestore document shape
```


# 1.2 Canonical Team identity in Club projections

`teamId` together with `teamSlot` (also named `birthTeamSlot` at source
boundaries) is the canonical identity of a team inside a Club projection.
The slot is not a display heuristic and must never be reconstructed from a
team name, array position, league level, birth year, or parsing `teamId`.

Competition Path keeps this identity end to end:

```text
League / Team identity
  -> Club age-group season and Competition Path season
  -> nextCompetitionPath.sourceTeamId + sourceTeamSlot
  -> Clubs Master compact projection
  -> ClubIntelligence Future League Path Spotlight
```

`nextCompetitionPath` records the source team. The Spotlight belongs to the
target cohort (`competitionPaths[].birthYear`): it resolves only the current
target team with the same canonical `teamSlot`. Both source and target must be
explicit; a consumer must never choose a candidate by name, array position,
league level, birth year, or parsing `teamId`.

The compact `Clubs Master` Competition Path follows the same rule:
`currentLeagueLevel` is taken only from the target team's catalog-current
season where `teamSlot === nextCompetitionPath.sourceTeamSlot`. It must never
be taken from the first item of a seasons array. Once a full Club/Clubs Master
identity backfill is complete, the Clubs page consumes `teamSlot` directly
from `Clubs Master` and does not load identity-index documents as a UI fallback.

## 1.3 Future League Path timing

The source cohort is the year immediately above the target cohort. Before the
source cohort has played 50% of its expected league games, its current league
level is the canonical early-season path (`CURRENT_LEVEL`). From 50% onward,
the path uses its calculated promotion/relegation projection.

`UNKNOWN` is reserved for a missing source team or missing loaded league table;
it is not used merely because the season is in its first half. A Future League
Path Spotlight is emitted for `CURRENT_LEVEL` and calculated statuses, but not
for `UNKNOWN`.

## 1.4 ClubIntelligence Signal Coverage

`ClubIntelligence.signalCoverage` is a runtime Domain contract. It is not a
Firestore field, not a Signal, and it never filters, changes, ranks, or
replaces a Spotlight.

Coverage reports whether the system had enough canonical information to check
the fixed focus age groups: `u14` (ילדים א׳) and `u15` (נערים ג׳). Signals for
all other age groups continue to be calculated and displayed normally, but do
not affect Coverage.

Each signal family returns this shape:

```text
{
  status: 'full' | 'partial' | 'none',
  coveredFocusAgeGroups: [{ ageGroupId, ageGroupLabel }],
  missingFocusAgeGroups: [{ ageGroupId, ageGroupLabel }],
  reasons: [{ ageGroup, requiredAgeGroup, reason }]
}
```

The independent families are `futureLeaguePath`, `leagueVsClubLevel`, and
`squadTask`. Offense and defense share the single `squadTask` availability
calculation because their canonical availability contract is the same.

For Future League Path, `u14` is covered only when the `u14 → u15` path is
calculable and `u15` only when the `u15 → u16` path is calculable. This
requires the primary team and league level for both age groups, plus the
canonical Competition Path with matching `sourceTeamId` and `sourceTeamSlot`.
`CURRENT_LEVEL` is a valid calculated path and therefore counts as covered.
When a Future Path requirement is missing, `requiredAgeGroup` identifies the
specific team age group that must be completed; it is not inferred by the UI.

For League Level vs Club Level, a focus group is covered only when the
canonical club level and that primary team's league level exist. A comparison
with no meaningful gap remains covered; it simply produces no Signal.

For Squad Task, coverage uses `teamTaskAvailability` directly, including its
canonical minimum-eight-games rule and reason. Coverage does not recreate that
availability logic.

The Summary always prioritizes a real Primary Signal. When none exists, it
shows `אין איתותים` only if all families are `full`; it shows `כיסוי חלקי` when
at least one family is `partial` and none is `none`. When all three families
are `none`, the fixed focus groups have no coverage in any signal family and
the Summary shows `אין כיסוי`. A mixed result that includes `none` is not
aggregated into `אין כיסוי` automatically.

# 2. Team Performance source of truth

## 2.1 Canonical source

`league.current/history.tableRank` is the canonical source of actual team performance.

The following fields belong to the Team Performance domain:

- `teamGamePlayed`
- `goalsFor`
- `goalsAgainst`
- `tableRank`
- `tableAttackRank`
- `tableDefenseRank`
- `goalsForPerGame`
- `goalsAgainstPerGame`

These fields must not be reconstructed from Player Stats.

## 2.2 Derived team-performance values

The following values are derived from the canonical league table data:

- `goalsForPerGame = goalsFor / teamGamePlayed`
- `goalsAgainstPerGame = goalsAgainst / teamGamePlayed`
- `tableAttackRank` = ranking by goals scored
- `tableDefenseRank` = ranking by goals conceded

All persisted per-game values must use a maximum of one decimal place.

## 2.3 Team Performance calculation context

Each League Season persists a compact `teamPerformanceContext`. It records the
Team Performance engine version and the league-wide normalization values used
for that season. The table rows remain the canonical official facts; the
context makes their derived Team Performance projection reproducible without
serializing the full offense/defense engine result into every row.

When a League table is loaded or changed, calculate the Team Performance
projection once for the whole table. The interactive request commits only the
canonical League Document and the compact Club-season identity index, then
queues a `dbLeagueProjectionJobs` record. This keeps League Import bounded and
allows the user to continue working.

The deployed background worker claims the job and applies the League-derived
performance to existing Team Season documents and their existing Team
SearchIndexes. It does not create Team Roots, Team Seasons, indexes, Player
Documents, Balance, or scout state. Club and Clubs Master projections are
refreshed by their explicit canonical rebuild flow. Roster and Stats loads must
reuse the League-derived projection and must not recalculate the whole League
table.

The current job lifecycle is `queued → processing → completed | failed`.
`completed` means the worker finished its defined scope (existing Team Season
performance), not that it owns every derived Players Database projection.
Each League write carries a `sourceRevision`; an attempt token and the
canonical League revision are checked before every Team Season write chunk, so
an older job cannot overwrite a newer League load. A 10-minute lease protects
the worker, and only expired leases are requeued by the narrow scheduled
recovery query.

Reloading a League Excel file follows the same path. It refreshes official
League-derived performance and existing Team SearchIndexes only for Team
Seasons that already exist. It does not fabricate Player Documents, missing
indexes, Club projections, balance or transfer data; those remain owned by
their matching explicit source flows.

The Team Season and Club projections persist only the compact
`{ priorityLevel }` offense/defense sides. The complete calculation remains a
runtime view derived from the League table and its season context.

Examples:

- `5.542` → `5.5`
- `1.125` → `1.1`
- `3` → `3`

The same normalization rule must be used by Team Season writers and Team SearchIndex projections.

---

# 3. Actual / Pace / Projected

For an active league season, three concepts must remain separate.

## 3.1 Actual

Official values that already occurred.

Examples:

- games played
- goals for
- goals against
- points
- table rank

Actual values come from the League Document.

## 3.2 Pace

A rate derived from actual values.

Examples:

- goals per game
- goals against per game

Pace does not replace actual values.

## 3.3 Projected

A forecast to the end of the season.

Examples:

- `projectedTeamGamePlayed`
- `projectedGoalsFor`
- `projectedGoalsAgainst`
- `projectedPoints`

Projected values are derived values and must never overwrite Actual values.

Example:

If a team has:
- 10 games played
- 20 goals
- 24 total league rounds

Then:

- `teamGamePlayed = 10`
- `goalsFor = 20`
- `goalsForPerGame = 2.0`
- `projectedTeamGamePlayed = 24`
- `projectedGoalsFor = 48`

---

# 4. Roster Load responsibility

Roster Load is responsible for:

- resolving player identities locally from the current/previous Team Season before broad identity lookup,
- writing the Team roster,
- creating/updating the Team Season snapshot,
- reconciling canonical Team Season movement state in `transfersIn`, `transfersOut` and open-only `pendingPlayers`,
- updating roster-related Team SearchIndex metadata,
- preserving canonical Team Performance,
- keeping scouting and balance state empty/insufficient when stats do not exist.

Roster Load must not:

- create Player Documents merely because a player is in a roster,
- invent Player Stats,
- create Scout Profiles,
- use Player Stats as Team Performance,
- overwrite canonical League Team Performance with defaults.

When a Team Season is created for the first time, canonical Team Performance must be supplied from the League table context. The writer must not depend only on `existingSeason`.

`existingSeason` may be used as a defensive fallback, but not as the primary source of truth.

## 4.1 Roster snapshot and Movement contract

Roster reload is a supported canonical operation. It must not fail only because
`teamPlayers` already exists. Every roster import carries compact metadata:

- `mode`: `AUTHORITATIVE_SNAPSHOT` or `PATCH`;
- `sourceSnapshotKey`: source-provided, unique snapshot/event identity when
  available. A generated key is allowed only as a fallback; it is reused for
  an identical `contentHash` reload and must not be used to infer timing;
- `contentHash`: deterministic roster-content fingerprint used only to detect
  an identical reload, never as the sole identity of a Movement event;
- `effectiveAt`: optional source-effective time.

The current paste flow is an `AUTHORITATIVE_SNAPSHOT`. When the source does not
provide a revision key, the UI derives a deterministic key from the Team Season
identity and roster identities. Identical reloads therefore reuse the same key.
A changed key alone does not prove an in-season transfer. Without reliable
source ordering/effective time, movement timing remains `UNKNOWN`.

Movement ownership is Team Season scoped:

- `transfersIn` and `transfersOut` are canonical movement facts for the season
  in which the movement took effect;
- `pendingPlayers` contains unresolved/open absences only;
- a certain counterpart is written automatically only when the counterpart
  Team Season already exists;
- a missing counterpart Team Season is legal and must never be created only to
  complete a movement;
- counterpart failure does not invalidate a successful local canonical write.

In Roster Import, identity verification is completed first for players present
in the incoming snapshot. The modal then presents only `regular` participants
from the previous season who are absent from that snapshot. A user-selected
destination Team Root and slot confirms `transfersOut`; an absent player with
no selected destination remains `pendingPlayers`. The snapshot must never
invent a destination or a Movement fact for an unchecked absence.

In the Roster Import review, an explicit `unknown` decision is a completed
manual decision: the row is approved for import and becomes `pendingPlayers`.
It creates no Movement fact and retains no invented destination.

For a player present in the incoming roster but absent from the immediately
previous Team Season, the review may explicitly classify the row as `joined`,
`priorAgeException` (the player had played as an age exception in the lower
age group), or `confirmedInRoster` (a manually confirmed prior-roster match).
Only `joined` requires a canonical source Team Root and slot and can create
`transfersIn`; the two internal confirmations create no Movement fact.

When no previous roster exists at all, incoming rows are accepted as the first
known roster snapshot: they are `regular` participants and require neither a
source classification nor a Movement fact.

An explicit `olderAgeException` resolution is internal: it means a player who
was allowed to play up/down as an age exception in the prior season has simply
returned to the applicable age group. It records a `resolvedRosterAbsences`
audit entry, creates neither a Movement fact nor a `pendingPlayers` entry, and
requires no destination Team Root or slot.

Movement identity/timing rules live in `domain/movement`. SearchIndex may help
resolve an unresolved player identity, but it is never the Movement source of
truth. Legacy `rosterStatus` transfer values and `manualTransferDirection` are removed.
`teamPlayers` contains every Season Participant, including a player who left
after contributing statistics. `rosterStatus` is only a membership/scope state:
`regular`, `left`, or `youngerAgeGroup`. Movement truth comes only from the Team
Season `transfersIn` and `transfersOut` arrays. Current Roster, `playersCount`,
Team Balance, line structure and scout summary scope include `regular` only.

## 4.2 Clean-reset Excel input contract

The clean-reset source files must preserve source data rather than Firestore
projection fields. Roster input must provide player name and should provide the
IFA player URL and/or external player id; position and shirt number may also be
provided. The parser may read `transferCheck` for QA display, but Movement
Domain, writers and projections must never use it to create a movement fact.
League/Team identity must remain resolvable from the selected League/Team
context. Snapshot metadata belongs to the import request, not to transfer QA.

---

# 5. Stats Load responsibility

Stats Load is the source of truth for player statistical data.

It may update:

- `teamPlayers[].playerStats`
- `statsStatus`
- Team Balance
- scouting calculations and compact projections
- relevant Player Documents when tracking/profile eligibility exists
- Player SearchIndex and Team SearchIndex projections

Stats Load must not use Player Stats totals to overwrite official Team Performance.

For a completed/historical season, a Stats row that is not in that Team
Season's original roster is blocked in the import modal until the user chooses
one of three participation facts: `left`, `joined`, or `youngerAgeGroup`.
`left` keeps the participant and statistics, sets `rosterStatus: left`, and
requires a canonical destination Team identity before writing `transfersOut`.
`joined` keeps `rosterStatus: regular` and requires a canonical source Team
identity before writing `transfersIn`. `youngerAgeGroup` writes no Movement.
This Stats-specific classification never creates `pendingPlayers`.

Both manual source and destination choices resolve to an existing Team Root's
full identity (`clubId`, `birthTeamId`, `birthTeamDocumentId`,
`birthTeamSlot`). A counterpart is written only when that Team Season already
exists. Outgoing-to-incoming and incoming-to-outgoing counterpart retries use
the same canonical reconciliation path.

For a player whose canonical `rosterStatus` is `left` or `youngerAgeGroup`, Stats
Load must keep the Team Season participant row and its historical statistics, but
must not include it in current-roster Balance or team scout scope. If
the player already has a Player Document, it must clear the current season's scout
projection. The document is retained only when another season/history or an
independent tracking reason remains; otherwise it is removed.

## 5.1 Pre-commit validation

Before a Stats Load commit, the League table projection is the mandatory
official context for `teamGamePlayed`, `goalsFor`, `goalsAgainst`, and the
competition/game-duration context. Player statistics are observed input and
must be validated against that context before Team Balance, scouting, Player
documents, or SearchIndex projections are updated.

Blocking contradictions include values that can be proven impossible without
assumption: a player's games above league games, starts above games, starts
above `teamGamePlayed × 11`, player or aggregate goals above `goalsFor`, and
minutes above the League-derived capacity. The UI must present these findings
for correction and keep commit disabled until they are resolved. It must not
silently clamp, truncate, or reconcile player input.

For Stats Load validation only, the minutes capacity includes a fixed observed
stoppage-time allowance of six minutes per league game. This allowance does
not change the canonical age-group `gameMinutes` or persisted
`playerStats.teamMinutes`. When no pasted row would become negative, the UI
may offer an explicit one-minute equal reduction for all pasted rows. The
user may repeat that action while an aggregate excess remains; the preview
must recompute scout profiles and disclose added/removed profiles before
commit. No increase is offered for a minutes deficit.

`playerStats.teamMinutes` is a derived context value. Stats Load derives it
canonically as `teamGamePlayed × gameMinutes`, where `gameMinutes` comes from
the age-group league catalog. It is not imported player input and must not use
a missing-input default of `0` when league games are known.

A player above 100% of this canonical `playerStats.teamMinutes` is a blocking
row-level validation error, even though aggregate minutes validation includes
the separate observed stoppage-time allowance.

Example:

League:
- `goalsFor = 133`

Loaded player stats:
- sum of player goals = 128

Canonical Team Performance remains:

- `goalsFor = 133`

The difference is a coverage/completeness issue, not a Team Performance correction.

If Stats Load receives a `team` payload containing Team Performance fields, that payload must not be allowed to override the canonical League-derived values unless it is itself explicitly built from the canonical League Team Performance projection.

---

# 6. Player Stats vs Team Performance

These are separate domains.

## 6.1 Shared player identity candidate resolution

Roster Load and Stats Load keep separate write policies, but use the same
candidate-resolution order: `externalPlayerId`, then `identityKey`, then
normalized aliases/name, then a Player Document fallback. The fallback may
surface an existing player only as a candidate; it must not auto-link when the
available context is not uniquely sufficient.

Player Document existence alone does not establish a canonical `playerId`.
A write flow may use an existing `playerDocumentId` only when a canonical
`playerId` mapping is independently resolved.

`playerId` values in the `player__...` namespace are internal identities only.
They must never be used as a Player Document ID or as a write target in the
`players` collection. Player Document writes are permitted only under canonical
document namespaces such as `external__...` or `name__...`. A `player__...`
value may be used only for relations, lookup, or a legacy read fallback.

Stats Load first preserves a `ROSTER_MATCH`. A player found in the system but
not in the team roster requires an explicit season status. `AMBIGUOUS` and
`UNRESOLVED` identities block both UI confirmation and the writer boundary.
An unmatched row must not create an internal player ID by default: creation
requires an explicit UI decision that is carried to the writer.

## Team Performance

Source:
- League Document

Examples:
- games
- team goals
- team rank
- attack rank
- defense rank

## Player Stats

Source:
- Stats Load

Examples:
- player games
- player goals
- player minutes
- starts
- substitute appearances

A mismatch between Player Stats totals and Team Performance must not cause Team Performance to be rewritten.

Such mismatches may influence:
- data coverage,
- reliability,
- Team Balance availability,
- audit diagnostics.

---

# 7. Team Balance

Team Balance is derived from player statistical coverage.

Before Stats Load:

- roster players may exist,
- `statsStatus` should be `missing`,
- `loadedCount = 0`,
- `reliability = insufficient`,
- unavailable balance metrics should remain unavailable,
- balance bands should remain `null`.

Team Balance interpretation is available only when the official
`teamGamePlayed` is at least 8 **and** relevant player statistics are loaded.
When `teamGamePlayed < 8`, its canonical state is
`availability: unavailable` with
`availabilityReason: season_sample_insufficient`. Once the eight-game gate is
met, deleted or not-yet-loaded stats use `stats_not_loaded`.
Performance remains available under its own rules. Balance facts may still be
computed, but Balance benchmarks, Team Interest and SearchIndex findings must
remain inactive while Balance is unavailable.

Team Balance must not be treated as an official Team Performance source.

Team Balance population scopes are explicit:

- **Season Participants**: Team Season players with season minutes. Movement
  facts do not change or replace their statistical evidence.
- **Current Relevant Roster**: `teamPlayers` whose `rosterStatus` is exactly
  `regular`. `left` and `youngerAgeGroup` remain season participants but are out
  of current-roster scope. Transfer state is never inferred from `rosterStatus`.

`playersCount` is the persisted Current Roster count: only `regular` players.

---

# 8. Scouting projection in Team Season Document

The Team Season Document may store a compact scouting projection for each roster player.

Typical compact fields include:

- `primaryScoutProfileId`
- `primaryScoutProfileStrengthDepthPct`
- `professionalScoutProfileIds`
- `preliminaryScoutProfileIds`
- `scoutPlayerInterestLevel`
- `scoutEffectiveImmediacyStatus`
- `scoutEngineVersion`

Roster Load does not create Scout Profiles.

These fields remain empty until scouting calculations are available.

`primaryScoutProfileId` is the primary **Core** profile only. It is not a
summary of every professional result. `professionalScoutProfileIds` contains
the active Core and Opportunity profile ids, while
`preliminaryScoutProfileIds` contains active Preliminary profile ids. Neither
array carries signals, hierarchy, evidence, or the full scouting result.
Team professional summaries use only `professionalScoutProfileIds`; a
Preliminary profile remains available to the Team UI, but is not a Team
professional summary. It is nevertheless a full Player lifecycle reason: a
Preliminary profile independently requires a Player Document, just as a
Professional profile does. Its result is synchronized into that document and
its SearchIndex projection.

The full scouting engine output must not be serialized into the Team Season Document.

---

# 9. Team SearchIndex

Team SearchIndex is a projection only.

It may contain:

- team identity
- league context
- official Team Performance projection
- projected season finish
- Team Balance bands
- scout summary
- roster metadata

It must not become an independent source of truth.

The same Team Performance calculation rules used for the Team Season Document must be used for the SearchIndex.

There must not be separate incompatible formulas for:

- goals per game
- goals against per game
- attack rank
- defense rank

---

# 10. Canonical flow

```text
League Document
      ↓
Canonical Team Performance
      ↓
 ┌──────────────────────┬────────────────┐
 ↓                      ↓                ↓
Team Season Document   Team SearchIndex  Active-season Projection
```

Player statistics follow a separate path:

```text
Stats Load
    ↓
Player Stats
    ↓
Team Balance / Scouting
    ↓
Compact Team + Player + SearchIndex projections
```

Player Stats must not become the canonical Team Performance source.

---

# 11. Field ownership summary

| Field / Area | Canonical source | Roster Load | Stats Load | SearchIndex |
|---|---|---|---|---|
| `teamGamePlayed` | League | copy/project | must not redefine | projection |
| `goalsFor` | League | copy/project | must not redefine | projection |
| `goalsAgainst` | League | copy/project | must not redefine | projection |
| `tableRank` | League | copy/project | must not redefine | projection |
| `tableAttackRank` | League-derived | copy/project | must not redefine | projection |
| `tableDefenseRank` | League-derived | copy/project | must not redefine | projection |
| `goalsForPerGame` | League-derived | canonical normalized value | preserve canonical | projection |
| `goalsAgainstPerGame` | League-derived | canonical normalized value | preserve canonical | projection |
| `playerStats` | Stats Load | empty/missing | source of truth | projection if needed |
| `teamBalance` | Player Stats-derived | insufficient | calculate | projection |
| `teamTaskSignals` | Team Balance interpretation | clear/refresh | calculate and project | not required |
| Scout profile projection | Scouting | empty | calculate | projection |
| Projected season finish | League actual + projection rules | may project | preserve/recompute canonically | projection |

---

# 12. Firestore write policy

Writers should remain narrow.

A writer should not:
- independently discover a new source of truth,
- duplicate domain calculations already owned by a canonical helper,
- reconstruct values from unrelated persisted projections,
- use SearchIndex as a fallback source.

Prefer:

```text
Source data
  ↓
domain/shared canonical builder
  ↓
normalized persistence payload
  ↓
writer
```

over:

```text
writer
  ↓
find data
  ↓
calculate business logic
  ↓
write
```

---

# 13. Audit / Repair / Migration

Audit is a read-only integrity check. It answers only these questions:

1. **Missing Document** — a canonical lifecycle contract proves a document must exist but it is absent.
2. **Source Mismatch** — a persisted projection differs from an Expected value built by a canonical builder from its canonical source.
3. **Broken Relation** — an explicit document linkage is missing, points to a missing document, or contradicts the linked entity identity.
4. **Unexpected Document** — a document exists although the canonical lifecycle proves it should not.
5. **Lifecycle Status** — a non-error explanation of why an entity and its projections exist.

Audit is **not** a schema validator. It does not compare Firestore document
fields to the Catalog and does not report missing fields, unexpected/legacy
fields, type mismatches, nested-shape mismatches, or schema-health scores.
`catalog/firestoreDocuments` remains the persistence-development contract for
writers and schema changes; it is not a runtime Audit engine.

Lifecycle is the basis for existence and relation checks. SearchIndex is
projection only and is never a source used to derive Expected values.

Repair is separate from the daily Audit flow and always requires explicit user
confirmation. The supported missing-Player-Document Repair first performs a
fresh read, groups validated entries by `league → season → team`, and uses the
canonical player and projection writers to create the document and refresh the
affected Team Season, Player SearchIndex, Team SearchIndex and League summary.
It must not provide schema repair or use SearchIndex as a Repair/Migration
source when the original domain source exists. SearchIndex may be used only to
show display context in the confirmation preview. Migration must not introduce
a second source of truth.

---

# 14. Current Player V3 boundary

Player persistence intentionally stores a compact scouting snapshot.

The full deterministic scouting result remains runtime/domain state.

Player Season persistence keeps compact fields such as:

- `scoutProfiles`
- `scoutProfileHierarchy`
- `scoutCombinationIds`
- `scoutOpportunity`
- `scoutPlayerInterest`
- `scoutProfileProgression`
- `scoutEngineVersion`

Rich runtime-only fields should not be restored into Player persistence unless this architecture document is intentionally changed.

`scoutPlayerInterest` is the compact player-level projection of the deterministic
interest calculation. It may persist the automatic score, maximum score, level,
and factor breakdown needed by the Player page; the calculation itself remains
owned by the shared scouting domain and is refreshed by Stats Load.

---

# 15. Rule for future changes

Before changing a Team/Stats/SearchIndex writer, answer:

1. What is the source of truth?
2. Is this value Actual, Pace, Projected, or derived Player state?
3. Is this writer allowed to own this field?
4. Does another writer already calculate the same value?
5. Can the value be reproduced deterministically?
6. Will this change create a second source of truth?

If any answer is unclear, stop and resolve the architecture before implementing the write.

---

# 16. Player line classification and current-team structure

## 16.1 Ownership and stored projection

`lineClassification` is a compact, season-scoped **performance** projection
for a Team Player and Player Season. It describes the player's role in that
specific season from the loaded statistics:

```text
line: DEFENSE | MIDFIELD | ATTACK
position: FULLBACK | ATTACKING_MIDFIELDER | null
```

It is not a replacement for the visually verified `positionLayer` and
`primaryPosition` fields. Those fields preserve the professional/visual
verification and must never be populated or overwritten by performance
classification. The classification is the canonical input to current-team
line analysis and performance-based scout reclassification.

The canonical classification builder is the shared team-line classification
domain. Writers must call that builder rather than recreate its rules. The
Team Season owns the current roster's classifications. A Player Season may
keep the same compact projection as player history, but a prior-season value
must never be used as a fallback for the current Team Season.

The Team Balance snapshot owns the derived `lineClassificationCoverage`,
`lineStructure`, `lineupBenchmark`, and compact `scoutInterpretation`
projections. `lineStructure` contains
facts only: the current counts, identified goalkeepers, classified players,
players with an 8+ sample who remain unclassified, and players below the
8-game sample. All counts include `regular` players only. A known goalkeeper is an identified role and is counted as
classified, while remaining outside the three field lines. `relevantPlayersCount`
is the real current-squad denominator. SearchIndex remains a projection only
and must not become a source for any balance value.

## 16.2 Classification decision order

Classification is decided from current-season performance only. It is derived
when sufficient current-season statistics are available and remains empty when
they are not. `primaryPosition` and `positionLayer` are not a classification
input and cannot change the performance result.

A visually verified `goalkeeper` / `GK` is excluded from field-player line
inference, so a goalkeeper cannot be misclassified as defense solely from
minutes. This exclusion does not make the visual fields a source of the
resulting line.

Known goalkeepers are counted separately in `lineStructure.goalkeeperPlayersCount`.
They are not included in `DEFENSE`, in the statistical-classification population,
or in the unclassified count.

## 16.3 Statistical inference rules

Statistical inference first identifies the line and only then refines the
position where the rules prove it:

- Fewer than 8 games: no statistical classification.
- 8 or more games and `10+` goals: `ATTACK`, with `position: null`.
- 8 or more games and fewer than 10 goals: continue through the personal
  minutes gate.
- Personal minutes rate is `playerMinutes / (playerGames × gameMinutes)`.
  Fewer than `70%` produces no classification; `70%` and above continues to
  the existing minutes and substitution matrix.
- Personal substitution rate is `substitutedOut / starts`. It is independent
  of the minutes context and is available whenever both the substitution count
  and at least one start are known.
- Inside that matrix, `5–9` goals produce `MIDFIELD` and
  `ATTACKING_MIDFIELDER` only after both gates have passed.
- The fullback rule may return `FULLBACK` only inside `DEFENSE`.

The model must not infer striker, centre-back, winger, or any other detailed
position without an explicit rule. `FULLBACK` and `ATTACKING_MIDFIELDER` are
the only statistical position refinements currently supported.

## 16.4 Current-team line structure

`lineStructure` measures the current team only. Its real-squad population
includes `regular` players only. The three field
line counts use loaded players that pass the 8-game classification gate;
goalkeepers come from the separately verified goalkeeper role.

### Minutes are the evidence chain for squad structure

Current-team structure is not an independent input beside player usage.
Player minutes are the underlying evidence for every subsequent structural
layer:

```text
Current-season player minutes and substitutions
    ↓
Personal minutes gate and line-classification matrix
    ↓
Proven player line / position
    ↓
Line structure and classification coverage
    ↓
Lineup benchmark and Team Balance interpretation
```

Consequently, the model's inability to establish enough proven lines is a
downstream squad-usage signal: the current allocation of minutes did not
produce sufficient evidence for a stable line structure. It must not be
treated as an independent position-data problem or as a manual-position
verification failure.

The evidence state remains important:

- Fewer than 8 player games is an **insufficient sample**, not a Team Balance
  conclusion.
- At 8+ games, a player who does not pass the personal-minutes gate or the
  classification matrix remains **unclassified with sufficient sample**. That
  is a structural coverage fact rooted in the minutes distribution; it can
  motivate balance investigation, but does not by itself assert shortage,
  quality, or recruitment need.

It is intentionally a derived-facts layer:

```text
Team Balance identifies current-squad facts
    ↓
Line Classification assigns line / proven position
    ↓
Line Structure counts the composition
    ↓
Benchmark Evaluation compares counts to a versioned reference
    ↓
Performance + Balance Interpretation may later decide a scouting finding
```

It must not emit `shortage`, `overload`, `need`, `opportunity`, a target flag,
or UI text. `FULLBACK` remains a factual position refinement only.

## 16.5 Reference Lineup Benchmark and evaluation

The canonical reference is defined once in:

`src/shared/scouting/teams/balance/benchmark/teamLineupStructureBenchmark.definition.js`

```text
GOALKEEPER: 1
DEFENSE: 4
MIDFIELD CORE: 3
ATTACKING_MIDFIELDER: 1
ATTACK: 2
```

`ATTACKING_MIDFIELDER` is a `MIDFIELD` subtype, so `midfieldCore` is the
MIDFIELD count less attacking midfielders. The same player is never counted
twice in the 3 + 1 reference.

The canonical evaluator is:

`src/shared/scouting/teams/balance/benchmark/evaluateTeamLineupStructureBenchmark.js`

It produces the persisted `lineupBenchmark` contract:

```text
definitionId, definitionVersion, availability, availabilityReason
metrics.<metric>.actual, reference, delta, state
```

The only evaluation states are `below_reference`, `at_reference`,
`above_reference`, and `unavailable`. This is a deterministic structural
comparison, not a verdict about shortage, quality, need, or opportunity. A
different age, level, or context can later select another versioned definition
without rewriting the evaluator.

## 16.6 Performance + balance interpretation and Team Interest V1

An unusual structure is information, not an automatic assertion that a team
is unbalanced. The versioned interpretation layer joins Team Performance,
Benchmark Evaluation, and classification coverage.

Team Interest V1 uses **only** the `ATTACK` and `DEFENSE` benchmark metrics.
`midfieldCore` and `attackingMidfielder` remain persisted structural
diagnostics and are displayed as `below_reference`, `at_reference`, or
`above_reference`; they must not generate a team-interest finding.

The performance band is derived from the existing Team Performance priority:
`POSITIVE`, `HIGH`, and `ELITE` are `positive_or_above`; `NEUTRAL` is
`regular`; `LOW` is `low`. The attack matrix is:

```text
positive_or_above + below/at/above = ATTACK_CONCENTRATION / ATTACK_ESTABLISHED / ATTACK_HIGH_COMPETITION
regular           + below/at/above = ATTACK_DEPTH_REVIEW / NO_CLEAR_FINDING / REVIEW_REQUIRED
low               + below/at/above = ATTACK_POSSIBLE_GAP / ATTACK_QUALITY_REVIEW / REVIEW_REQUIRED
```

The defense matrix is:

```text
positive_or_above + below/at/above = DEFENSE_CONCENTRATION / DEFENSE_ESTABLISHED / DEFENSE_QUALITY_SEARCH
regular           + below/at/above = DEFENSE_DEPTH_REVIEW / NO_CLEAR_FINDING / REVIEW_REQUIRED
low               + below/at/above = DEFENSE_POSSIBLE_GAP / DEFENSE_QUALITY_REVIEW / DEFENSE_LOW_QUALITY_OVERLOAD
```

`REVIEW_REQUIRED` is intentional: no professional conclusion has been
approved for that combination yet. The canonical `teamInterest.isInteresting`
is true only for the approved line findings in the domain; its list is
intentionally explicit in `isTeamInterpretationFindingInteresting` and must
not be inferred from a UI label.
There is no separate Agent versus Club Scout interest model.

SearchIndex projects only the interpretation model version, availability,
attack finding, defense finding, and derived interest flag. It never stores
the whole benchmark evaluation.

Team Interest also includes a separate Squad Interest source. The canonical
`classification-coverage-v1` benchmark evaluates `classifiedPlayersCount`
against the versioned typical range `10–13`, returning `below_typical`,
`typical`, `above_typical`, or `unavailable`. These are structural facts, not
Squad Interest by themselves. Squad Interest is active only when coverage is
below or above typical and the two performance bands form one of these
combinations:

```text
two_positive     = offense positive_or_above + defense positive_or_above
positive_and_low = one positive_or_above + one low
two_low          = offense low + defense low
```

If either performance band is `regular`, or a performance band is unavailable,
no Squad Interest event is produced. This evaluation never gates the line
benchmark.

For an active Squad Interest event, the domain derives two non-persisted action
contexts from the coverage reason and the performance combination:

- `teamNeed`: the current team's quality/depth need;
- `marketOpportunity`: an opportunity to identify or monitor quality players
  for other teams.

Each action has a stable action id and optional `targetSides` (`offense`,
`defense`). These are runtime interpretation outputs only. They must not be
written to Team Season documents or SearchIndex merely to support display;
the persisted coverage reason and performance inputs remain the source data.

The same action shape is used by approved attack and defense findings. A line
finding may derive a `teamNeed`, a `marketOpportunity`, both, or neither. For
example, line concentration derives depth-building for the current team and
monitoring of its leading players for the market; line quality search derives
a market opportunity only. The action mapping is domain-owned and runtime-only,
while Hebrew labels remain a presentation concern.

`teamInterest` is the versioned business summary with three independent
sources: line offense, line defense, and approved squad coverage/performance
interpretation. `teamInterest.isInteresting` is the OR of those sources. This mirrors the
purpose of Player Interest—whether further attention is justified. The
interest decision remains singular; `teamNeed` and `marketOpportunity` are
separate action contexts derived after that decision.

The interpretation layer is unavailable before eight official league games
(`season_sample_insufficient`); once that gate is met, cleared or not-yet-
loaded stats use `stats_not_loaded`. In either state all benchmark metric states are
`unavailable`, Team Interest is false, and the Team SearchIndex receives no
active Balance finding. These gates never change Team Performance.

## 16.7 Write and invalidation flow

Stats Load derives and persists each Team Player's `lineClassification` from
the canonical builder before rebuilding Team Balance. The resulting
classification is passed into scout calculation: it reclassifies
`preliminary_low_output` ("מחפש זהות") using the performance line, without
changing `primaryPosition`, `positionLayer`, or visual-verification answers.

A manual role or position change updates only the visual-verification fields
and must:

```text
update current Team Player role
    ↓
recompute lineClassification with the canonical builder
    ↓
invalidate or rebuild the Team Balance snapshot
    ↓
recompute lineStructure, lineupBenchmark and their fingerprint
    ↓
refresh downstream projections
```

The Team Balance input fingerprint must include `lineClassification`; a role
edit must therefore never leave a fresh-looking snapshot with stale line
structure. Catalog definitions for Team Season and Player Season must remain
aligned whenever the compact classification or structure projection changes.

## 16.8 SearchIndex projection

`dbSearchIndexes` is a read/search projection and not a source of truth. Each
Player Season index row carries the flat performance fields:

```text
lineClassificationLine
lineClassificationPosition
lineClassificationSource
lineClassificationEvidenceLevel
lineClassificationModelVersion
```

The same row may also carry `primaryPosition` and `positionLayer`, but those
remain the visual-verification fields. Stats Load updates the flat
`lineClassification*` fields and scout-profile summary; it must not replace
the visual fields.

For Team Balance, the Team Season index stores only the balance dependency
versions and the compact `scoutInterpretationModelVersion`,
`scoutInterpretationAvailability`, `scoutInterpretationAvailabilityReason`, `scoutOffenseFinding`,
`scoutDefenseFinding`, and `teamInterest` projection. It does not duplicate
the line-structure facts or the full `lineupBenchmark` evaluation.

## 17. League task-signal projection

`teamBalance.scoutInterpretation` is the canonical professional analysis for a
Team Season. The domain derives a compact `teamTaskSignals` object from its
line findings:

```js
{ offense: boolean, defense: boolean }
```

The value is `true` when the relevant line has either a team-need task or a
market-opportunity task. It is not an "interest" flag and it deliberately does
not persist task labels, task text, or player lists.

The Team Season snapshot keeps this calculated object under
`teamBalance.teamTaskSignals`. The League Document mirrors it to the matching
`current/history.tableRank[].teamTaskSignals` row with an `updatedAt` value.
This compact read-model projection lets the League Page render its task badge
from the existing single League-document read, without loading Team Season or
SearchIndex documents for every table row.

Every writer that recalculates Team Balance (stats load/clear, roster changes,
manual role changes, and audit repair) must pass the new projection to the
League table-row writer. The League projection is never used as an input to
Team Balance; missing legacy fields render as `false` until the next relevant
write refreshes them.

## 18. Club-season identity index

`dbClubsMaster/all` is a full display projection and must not be read merely
to validate a pasted league table. The same collection also contains compact
advisory identity-index documents, one per `seasonKey + birthYear`, for example
`identity__26-27__2011`.

Each index stores only the identity needed by the import preflight and by
targeted multi-season Team-page discovery:
`clubId`, `ageGroupId`, `teamId`, `teamSlot`, `leagueId`, `leagueName`, and
`leagueLevel`. League Documents remain the canonical source. The index is
updated once after a League table is committed, replacing only entries of that
League in its season/year document. Clearing or deleting a League season
removes its entries. A full Club-projection refresh also backfills the index
from existing League Documents.

The Level-2-and-below import modal reads one matching index document to flag a
club already present in the same season/year/age group in another League. The
warning requires an explicit team-slot confirmation. Level 1 skips this read:
those entries are treated as first teams.

The Team Page may read the compact index documents for one birth year to locate
candidate League Documents across seasons. Every candidate must then be read
from its exact League Document and verified against that season's table before
it is displayed. An absent index entry is never proof that a League-table team
does not exist; the source League Document used to open the page remains a
valid fallback.

## Clean reset and Movement recovery

The clean reset is Excel-first. League, Roster and Stats are loaded through the normal application flows; Audit validates those writes and must not synthesize the reset state.

Movement counterpart recovery is non-blocking. When a local `transfersIn` fact exists and the source Team Season also exists, Audit may report a missing `transfersOut` counterpart. A missing source Team Season is legal. Recovery may retry the counterpart write, but it must never create a Team Root or Team Season solely to complete Movement.

See `CLEAN_RESET_RUNBOOK.md` for the operational acceptance sequence.

## 19. Team Stats projection receipt

Every Players Database write starts by creating a central operational receipt:
`dbWriteActions/{writeActionId}`. This receipt is intentionally separate from
the Team Root and Team Season business documents: a failed import can be
identified even when neither target document exists. It records the action
type, lifecycle (`in_progress`, `completed`, `failed`, or
`failed_after_canonical_commit`), the narrow Audit scope when one exists, and
the relevant target and projection-job ids.

The receipt is mandatory. If it cannot be created, the business write does not
start. A receipt must never be best-effort because that would permit a write
which cannot be traced, audited, or repaired as one operation. A queued
background Job keeps its receipt in `in_progress`; it is not a failed partial
write. Its Cloud Function updates that same receipt to `completed`,
`failed_after_canonical_commit`, or `superseded` only after an attempt with the
same job id, source revision, and attempt token reaches that outcome. A lease
retry replaces the attempt token when it claims the Job; a late attempt can
therefore neither complete the Job nor change its receipt.

Each Stats Load also writes a `statsProjectionRevision` into the canonical
`dbBirthTeamSeasons/{teamId}__{seasonKey}` document and queues one scoped
`dbTeamStatsProjectionJobs/{teamId}__{seasonKey}__{revision}` document. The
job links back to the central receipt through `writeActionId`. The job has the
same contract for active and completed seasons; only `target` differs
(`current` versus `history`).

The worker always re-reads the Team Season and accepts it only when its
revision equals the job source revision. A newer Stats Load supersedes an
older queued or processing attempt, so a stale job cannot report or apply an
outdated result. The receipt records the canonical Team Season id, the player
document ids in scope, and the Player Season search-index ids. The import
modal displays the job id and outcome, and a failed job can be retried without
reloading the pasted data.

The operational receipt is the handoff identity for a targeted Audit: the
Audit modal accepts its `writeActionId`, resolves its stored scope, and runs
only that scope. It is not a full-database scan.

Roster Loads use the same ownership rule. Every canonical roster write stores
`rosterProjectionRevision` in Team Season. Each downstream roster projection
re-reads that canonical document without the client cache and stops when a
newer roster load owns the revision. Any downstream roster failure after the
canonical Team Season commit is recorded as
`failed_after_canonical_commit`, never as an early write failure.
