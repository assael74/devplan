// features/playersDatabase/model/shared/season.model.js

import {
  cleanValue,
  pickFirstValue,
} from './value.model.js'

export const SEASON_STATUS = Object.freeze({
  NOT_STARTED: 'not_started',
  ACTIVE: 'active',
  COMPLETED: 'completed',
})

export const normalizeSeasonStatus = (value, fallback = SEASON_STATUS.ACTIVE) => {
  const status = cleanValue(value).toLowerCase()

  return Object.values(SEASON_STATUS).includes(status)
    ? status
    : fallback
}

export const getSeasonTarget = seasonStatus => (
  normalizeSeasonStatus(seasonStatus) === SEASON_STATUS.COMPLETED
    ? 'history'
    : 'current'
)

export const buildSeasonKey = seasonId =>
  cleanValue(seasonId).replace(/[^0-9a-zA-Z]+/g, '_')

export const normalizeSeasonLookupKey = value => {
  const key = cleanValue(value)
  if (!key) return ''

  const fullMatch = key.match(/^20(\d{2})\s*[\/_-]\s*20(\d{2})$/)
  if (fullMatch) return `${fullMatch[1]}/${fullMatch[2]}`

  const shortMatch = key.match(/^(\d{2})\s*[\/_-]\s*(\d{2})$/)
  if (shortMatch) return `${shortMatch[1]}/${shortMatch[2]}`

  return key.replace(/_/g, '/')
}

export const normalizeSeasonIdentity = ({
  season = {},
  fallback = {},
} = {}) => {
  const safeSeason = season && typeof season === 'object' ? season : {}
  const safeFallback = fallback && typeof fallback === 'object' ? fallback : {}
  const seasonId = cleanValue(pickFirstValue(
    safeSeason.seasonId,
    safeFallback.seasonId
  ))
  const suppliedSeasonKey = cleanValue(pickFirstValue(
    safeSeason.seasonKey,
    safeFallback.seasonKey
  ))
  const seasonKey = suppliedSeasonKey || buildSeasonKey(seasonId)

  return {
    seasonId: seasonId || seasonKey,
    seasonKey,
  }
}

export const resolveSeasonId = value =>
  normalizeSeasonIdentity({ season: value }).seasonId

export const resolveSeasonKey = value =>
  normalizeSeasonIdentity({ season: value }).seasonKey

export const resolveSeasonLookupKey = value => {
  const identity = normalizeSeasonIdentity({ season: value })

  return normalizeSeasonLookupKey(
    identity.seasonKey || identity.seasonId
  )
}

export const isSameSeason = (left = {}, right = {}) => {
  const leftSeason = normalizeSeasonIdentity({ season: left })
  const rightSeason = normalizeSeasonIdentity({ season: right })
  const leftLookupKey = resolveSeasonLookupKey(left)
  const rightLookupKey = resolveSeasonLookupKey(right)

  return Boolean(
    (
      leftLookupKey &&
      rightLookupKey &&
      leftLookupKey === rightLookupKey
    ) ||
    (
      leftSeason.seasonKey &&
      rightSeason.seasonKey &&
      leftSeason.seasonKey === rightSeason.seasonKey
    ) ||
    (
      leftSeason.seasonId &&
      rightSeason.seasonId &&
      leftSeason.seasonId === rightSeason.seasonId
    )
  )
}
