// features/playersDatabase/ui/pages/leaguePage/hooks/useLeagueTableImport.js

import * as React from 'react'

import { useSnackbar } from '../../../../../../ui/core/feedback/snackbar/SnackbarProvider.js'
import { mapFirestoreErrorToDetails } from '../../../../../../ui/core/feedback/snackbar/snackbar.format.js'
import { SNACK_STATUS } from '../../../../../../ui/core/feedback/snackbar/snackbar.model.js'
import { PLAYERS_DATABASE_CLUBS_CATALOG } from '../../../../catalog/clubs.catalog.js'
import {
  PLAYERS_DATABASE_WRITE_ACTIONS,
  runPlayersDatabaseWriteAction,
} from '../../../../services/write/index.js'
import {
  buildLeagueImportPreview,
  buildServiceLeague,
  buildServiceRows,
  buildServiceSeason,
  formatGoalDifference,
} from '../logic/leagueImport.logic.js'

const clean = value => String(value === null || value === undefined ? '' : value).trim()

const toImportNumber = value => {
  const nextValue = Number(clean(value).replace(/\u200E/g, ''))
  return Number.isFinite(nextValue) ? nextValue : null
}

const isImportRowReady = row => {
  if (!clean(row?.clubId)) return false
  if (!clean(row?.teamSlot)) return false
  if (!Number.isFinite(toImportNumber(row?.rank)) || toImportNumber(row?.rank) <= 0) return false

  return [
    'games',
    'wins',
    'draws',
    'losses',
    'goalsFor',
    'goalsAgainst',
    'points',
  ].every(field => {
    const value = toImportNumber(row?.[field])
    return Number.isFinite(value) && value >= 0
  })
}

export function useLeagueTableImport({
  league = {},
  leagueDoc = {},
  selectedSeasonOption = {},
  reload,
} = {}) {
  const { notify } = useSnackbar()
  const [open, setOpen] = React.useState(false)
  const [pasteValue, setPasteValue] = React.useState('')
  const [rows, setRows] = React.useState([])
  const [busy, setBusy] = React.useState(false)
  const [previewMessage, setPreviewMessage] = React.useState('')
  const [writeReport, setWriteReport] = React.useState(null)
  const canConfirm = React.useMemo(() => {
    return rows.length > 0 && rows.every(isImportRowReady)
  }, [rows])

  const handlePreview = React.useCallback(() => {
    const preview = buildLeagueImportPreview({
      text: pasteValue,
      league,
      leagueDoc,
      selectedSeasonOption,
    })

    setRows(preview.rows || [])
    setPreviewMessage(preview.message || '')
  }, [pasteValue, league, leagueDoc, selectedSeasonOption])

  const handleClear = React.useCallback(() => {
    if (busy) return

    setPasteValue('')
    setRows([])
    setPreviewMessage('')
  }, [busy])

  const handleCellChange = React.useCallback(({ rowIndex, column, value }) => {
    setRows(currentRows => currentRows.map((row, index) => {
      if (index !== rowIndex) return row

      const nextRow = {
        ...row,
        [column.key]: value,
      }

      if (column.key === 'clubId') {
        const club = PLAYERS_DATABASE_CLUBS_CATALOG.find(item => item.id === value)
        nextRow.clubName = club?.name || ''
      }

      if (column.key === 'teamSlot') nextRow.teamSlot = value || '1'
      if (column.key === 'goalDifference') {
        nextRow.goalDifference = formatGoalDifference(value)
      }

      const valid = isImportRowReady(nextRow)
      nextRow.valid = valid
      nextRow.errors = valid ? [] : (Array.isArray(nextRow.errors) ? nextRow.errors : [])

      return nextRow
    }))
  }, [])

  const handleConfirm = React.useCallback(async () => {
    const serviceLeague = buildServiceLeague({
      league,
      leagueDoc,
    })
    const serviceSeason = buildServiceSeason({
      league,
      leagueDoc,
      selectedSeasonOption,
    })
    const serviceRows = buildServiceRows({
      rows,
      league: serviceLeague,
      season: serviceSeason,
    })

    setBusy(true)

    try {
      const result = await runPlayersDatabaseWriteAction({
        actionType: PLAYERS_DATABASE_WRITE_ACTIONS.PASTE_LEAGUE_TABLE,
        payload: {
          league: serviceLeague,
          season: serviceSeason,
          target: selectedSeasonOption?.target || 'current',
          rows: serviceRows,
        },
      })

      notify({
        status: SNACK_STATUS.SUCCESS,
        title: 'טבלת הליגה נשמרה',
        message: String(result.rowsCount || serviceRows.length) + ' שורות עודכנו',
      })

      setOpen(false)
      setPasteValue('')
      setRows([])
      setPreviewMessage('')
      reload()
    } catch (error) {
      setOpen(false)
      setWriteReport(error?.writeReport || {
        flow: 'pasteLeagueTable',
        status: 'failed',
        failedStage: error?.stage || 'unknown',
        message: error?.message || 'טעינת טבלת הליגה נכשלה',
        completedStages: Object.keys(error?.results || {}),
        failures: [{
          code: error?.code || 'WRITE_FLOW_FAILED',
          message: error?.message || 'טעינת טבלת הליגה נכשלה',
        }],
        duplicates: [],
        results: error?.results || {},
      })

      notify({
        status: SNACK_STATUS.ERROR,
        title: 'טעינת טבלת הליגה נכשלה',
        message: serviceLeague.name || 'ליגה',
        details: mapFirestoreErrorToDetails(error),
      })
    } finally {
      setBusy(false)
    }
  }, [league, leagueDoc, selectedSeasonOption, rows, notify, reload])

  return {
    open,
    pasteValue,
    rows,
    canConfirm,
    busy,
    previewMessage,
    setOpen,
    setPasteValue,
    handlePreview,
    handleClear,
    handleCellChange,
    handleConfirm,
    handleClose: () => setOpen(false),
    handleOpen: () => setOpen(true),
    writeReport,
    closeWriteReport: () => setWriteReport(null),
  }
}
