// features/playersDatabase/ui/components/tables/dataTable/DataTable.js

import * as React from 'react'
import {
  Box,
  Table,
} from '@mui/joy'

import { dataTableSx as sx } from './sx/dataTable.sx.js'
import DataTableBody from './DataTableBody.js'
import DataTableHeader from './DataTableHeader.js'
import {
  DATA_TABLE_SORT_DIRECTIONS,
  sortDataTableRows,
} from './dataTable.sort.js'
import exportDataTableRowsToXlsx from './dataTable.export.js'

export default function DataTable({
  columns = [],
  rows = [],
  getRowKey,
  emptyText = 'אין נתונים להצגה',
  className,
  wrapSx,
  tableSx,
  bodyScrollSx,
  defaultSort,
  renderExpandedRow,
  getRowSx,
  exportConfig = null,
}) {
  const [expandedRowKey, setExpandedRowKey] = React.useState('')
  const [sortState, setSortState] = React.useState(() => ({
    key: defaultSort?.key || '',
    direction: defaultSort?.direction === DATA_TABLE_SORT_DIRECTIONS.ASC
      ? DATA_TABLE_SORT_DIRECTIONS.ASC
      : DATA_TABLE_SORT_DIRECTIONS.DESC,
  }))

  React.useEffect(() => {
    setSortState({
      key: defaultSort?.key || '',
      direction: defaultSort?.direction === DATA_TABLE_SORT_DIRECTIONS.ASC
        ? DATA_TABLE_SORT_DIRECTIONS.ASC
        : DATA_TABLE_SORT_DIRECTIONS.DESC,
    })
  }, [defaultSort?.key, defaultSort?.direction])

  const sortableColumns = React.useMemo(
    () => new Map(
      columns
        .filter(column => column.sortable !== false)
        .map(column => [column.key, column])
    ),
    [columns]
  )

  const sortedRows = React.useMemo(() => sortDataTableRows({
    rows,
    column: sortableColumns.get(sortState.key),
    direction: sortState.direction,
  }), [rows, sortState, sortableColumns])

  const handleSort = column => {
    if (column.sortable === false) return

    setSortState(current => {
      if (current.key !== column.key) {
        return {
          key: column.key,
          direction: column.defaultSortDirection === (
            DATA_TABLE_SORT_DIRECTIONS.ASC
          )
            ? DATA_TABLE_SORT_DIRECTIONS.ASC
            : DATA_TABLE_SORT_DIRECTIONS.DESC,
        }
      }

      return {
        key: column.key,
        direction: current.direction === DATA_TABLE_SORT_DIRECTIONS.ASC
          ? DATA_TABLE_SORT_DIRECTIONS.DESC
          : DATA_TABLE_SORT_DIRECTIONS.ASC,
      }
    })
  }

  const toggleExpandedRow = rowKey => {
    setExpandedRowKey(current => (current === rowKey ? '' : rowKey))
  }

  const handleExport = React.useCallback(() => {
    if (!exportConfig?.enabled) return false

    const exportRows = typeof exportConfig.getRows === 'function'
      ? exportConfig.getRows(sortedRows, {
        rawRows: exportConfig.rawRows || [],
      })
      : sortedRows

    return exportDataTableRowsToXlsx({
      rows: exportRows,
      columns: exportConfig.columns || [],
      fileName: exportConfig.fileName,
      sheetName: exportConfig.sheetName,
    })
  }, [exportConfig, sortedRows])

  const header = (
    <DataTableHeader
      columns={columns}
      sortState={sortState}
      onSort={handleSort}
      exportConfig={exportConfig}
      onExport={handleExport}
    />
  )

  const body = (
    <DataTableBody
      columns={columns}
      rows={sortedRows}
      getRowKey={getRowKey}
      emptyText={emptyText}
      expandedRowKey={expandedRowKey}
      onToggleExpandedRow={toggleExpandedRow}
      renderExpandedRow={renderExpandedRow}
      getRowSx={getRowSx}
    />
  )

  const splitWrapSx = [
    sx.wrap,
    sx.splitWrap,
    wrapSx,
  ]

  const headerTableSx = [
    sx.table,
    sx.headerTable,
    tableSx,
  ]

  const bodyWrapSx = [
    sx.bodyWrap,
    bodyScrollSx,
  ]

  const bodyTableSx = [
    sx.table,
    sx.bodyTable,
    tableSx,
  ]

  const regularWrapSx = [
    sx.wrap,
    wrapSx,
  ]

  const regularTableSx = [
    sx.table,
    tableSx,
  ]

  if (bodyScrollSx) {
    return (
      <Box
        className={className}
        sx={splitWrapSx}
      >
        <Box sx={sx.headerWrap}>
          <Table
            size='sm'
            sx={headerTableSx}
          >
            {header}
          </Table>
        </Box>

        <Box
          className='dpScrollThin'
          sx={bodyWrapSx}
        >
          <Table
            hoverRow
            size='sm'
            sx={bodyTableSx}
          >
            {body}
          </Table>
        </Box>
      </Box>
    )
  }

  return (
    <Box
      className={className}
      sx={regularWrapSx}
    >
      <Table
        hoverRow
        stickyHeader
        size='sm'
        sx={regularTableSx}
      >
        {header}
        {body}
      </Table>
    </Box>
  )
}
